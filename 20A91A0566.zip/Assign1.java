import java.util.*;
import java.util.Collections;
class Assign1
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int n;
        n=sc.nextInt();
        ArrayList<Integer>arr=new ArrayList<>();
        for(int i=0;i<n;i++)
        {
            arr.add(sc.nextInt());
        }
        ArrayList<Integer>list=new ArrayList<>();
        int k=sc.nextInt();
        for(int i=1;i<k;i++)
        {
            if(arr.contains(i)==false)
            {
                list.add(i);
            }
        }
        System.out.println(list);
    }
}