import java.util.*;
import java.util.Collections;
class Assign2
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        HashMap<Integer,Integer>hash=new HashMap<>();
        int n;
        n=sc.nextInt();
        for(int i=0;i<n;i++)
        {
            int k=sc.nextInt();
            if(hash.containsKey(k))
            {
                hash.put(k,hash.get(k)+1);
            }
            else{
                hash.put(k,1);
            }
        }
        for(Map.Entry<Integer,Integer>ott:hash.entrySet())
        {
            if(ott.getValue()==1)
            {
                System.out.print(ott.getKey()+" ");
            }
        }
    }
}