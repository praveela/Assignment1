import java.util.*;
class Cumulative
{
public static void main(String[] args) {
    Scanner s=new Scanner(System.in);
    System.out.println("Enter the size of array");
    int n=s.nextInt();
    System.out.println("Enter the Elements into Array:");
    int a[]=new int[n];
    for(int i=0;i<n;i++)
    a[i]=s.nextInt();
    System.out.print(a[0]+" ");
    for(int i=1;i<n;i++)
    {
        a[i]=a[i]+a[i-1];
        System.out.print(a[i]+" ");
    }
    // int pre[]=new int[n];
    // pre[0]=a[0];
    // for(int i=1;i<n;i++)
    // pre[i]=pre[i-1]+a[i];
    // System.out.println("Cumulative Sum Array:");
    // for(int i=0;i<n;i++)
    // System.out.print(pre[i]+" ");
     s.close();
}
}